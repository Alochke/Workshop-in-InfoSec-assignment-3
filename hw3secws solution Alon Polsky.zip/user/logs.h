#ifndef LOGS
#define LOGS

#include "main.h"
#include "fw.h"


int logs_read(int);

#endif