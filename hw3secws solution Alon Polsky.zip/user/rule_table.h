#ifndef RULE_TABLE
#define RULE_TABLE
#include "list.h"
#include "fw.h"
#include "main.h"

int rule_table_init(rule_t**, list*);
int rule_table_print(FILE*);

#endif
