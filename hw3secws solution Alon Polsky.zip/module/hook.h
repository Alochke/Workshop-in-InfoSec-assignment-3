#ifndef HOOK
#define HOOK
#include "main.h"
#include "rule_table.h"
#include "logs.h"

int hook_init(void);
void hook_destroy(void);

#endif